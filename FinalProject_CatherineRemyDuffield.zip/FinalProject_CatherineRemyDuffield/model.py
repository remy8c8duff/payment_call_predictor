# Catherine Remy Duffield, 001529006, INF428, Final Project
# basic start
import pandas as pd

# import ml packages
from sklearn.model_selection import train_test_split as tts
from sklearn.linear_model import LogisticRegression as lr
from sklearn.metrics import classification_report as c_r
import sklearn.metrics as metrics

# import pickling packages
import pickle

# import data
df = pd.read_csv('data.csv')
print(df.head())

# get the summary
df.info()

# fill null data
clean_df = df.fillna(0)
clean_df.info()

# simplifying data in columns
clean_df['POLICY_RATE'] = clean_df['RTD_ST_CD'].str.lstrip('ST_S').astype('int64')
clean_df['MART_No'] = clean_df['MART_STATUS'].str.lstrip('MS_S').astype('int64')
clean_df.drop(['RTD_ST_CD', 'MART_STATUS'], axis=1, inplace=True)
print(clean_df.head())

# fix data type to numbers
clean_df.loc[clean_df['CustomerSegment'] == 'NONE', 'CustomerSegment'] = 0
clean_df.loc[clean_df['GENDER']== 'M', 'GENDER'] = 0
clean_df.loc[clean_df['GENDER']== 'F', 'GENDER'] = 1
clean_df[['CustomerSegment', 'GENDER']] = clean_df[['CustomerSegment', 'GENDER']].apply(pd.to_numeric)
print(clean_df.head())

# select independent and dependent variables
x = clean_df[['CustomerSegment',
              'Tenure',
              'Age',
              'GENDER',
              'CHANNEL1_6M',
              'CHANNEL2_6M',
              'CHANNEL3_6M',
              'CHANNEL4_6M',
              'CHANNEL5_6M',
              'RECENT_PAYMENT',
              'PAYMENTS_6M',
              'NOT_DI_3M',
              'NOT_DI_6M',
              'EVENT2_90_SUM',
              'LOGINS',
              'MART_No']]
y = clean_df['Call_Flag']

# data set split for train set and test set
x_train, x_test, y_train, y_test = tts(x, y, test_size=0.2, random_state=50)

# the lesson
call_lr = lr(solver='lbfgs', max_iter=500000).fit(x_train, y_train)

# the test
predict = call_lr.predict(x_test)
print(c_r(y_test, predict))

# evaluate prediction model
print('Accuracy:', metrics.accuracy_score(y_test, predict))
print('Recall: ', metrics.recall_score(y_test, predict, zero_division = 1))
print("Precision:", metrics.precision_score(y_test, predict, zero_division = 1))

# make pickle file
pickle.dump(call_lr, open("model.pkl", "wb"))