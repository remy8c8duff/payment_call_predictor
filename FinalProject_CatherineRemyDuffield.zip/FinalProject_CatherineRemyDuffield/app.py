import numpy as np
from flask import Flask, request, render_template
import pickle

# Create flask app
app = Flask(__name__)

# load pickle
model = pickle.load(open("model.pkl", "rb"))

# connecting to html
@app.route("/", methods=['GET'])
def home():
    return render_template("index.html")

# wip app functions
@app.route("/predict", methods=["POST"])
def predict():
    float_features = [float(x) for x in request.form.values()]
    features = [np.arry(float_features)]
    prediction = model.predict(features)
    if prediction == 1:
        return render_template("index.html",
                               prediction_text="The policyholder is predicted to make a service payment call.")
    else:
        return render_template("index.html",
                               prediction_text="The policyholder is predicted to not make a service payment call.")


if __name__ == "__main__":
    app.run(debug=True)
